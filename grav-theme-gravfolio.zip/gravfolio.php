<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class GravFolio extends Theme
{

}