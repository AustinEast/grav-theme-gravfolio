# Gravfolio
### A Portfolio Theme for Grav CMS

This theme serves as the basis of [my website](austineast.me) (currently).
While there are a couple of things that are still under development, it is for the most part feature complete.

## Features

* [MixItUp](https://mixitup.kunkalabs.com) portfolio sorting
* Blog pages
* easily switch between "One-page" design and normal multipage.

## Install

Download a zip of the master branch and upload it to your user/themes folder

## Usage

_Coming Soon!_
